// db.js
// Handles SQLite storage for:
// 1. Latest QR (single row, overwritten on update)
// 2. Pending screenshots (mapping screenshot -> user, so admin can confirm)

const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'data.db'));

db.pragma('journal_mode = WAL');

// Table to store the current QR (only ever 1 row, id = 1)
db.exec(`
  CREATE TABLE IF NOT EXISTS qr (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    file_id TEXT NOT NULL,
    updated_at TEXT NOT NULL
  )
`);

// Table to store pending screenshots awaiting admin confirmation
db.exec(`
  CREATE TABLE IF NOT EXISTS pending_screenshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    username TEXT,
    file_id TEXT NOT NULL,
    admin_message_id INTEGER,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TEXT NOT NULL
  )
`);

function setQr(fileId) {
  const now = new Date().toISOString();
  db.prepare(`
    INSERT INTO qr (id, file_id, updated_at)
    VALUES (1, ?, ?)
    ON CONFLICT(id) DO UPDATE SET file_id = excluded.file_id, updated_at = excluded.updated_at
  `).run(fileId, now);
}

function getQr() {
  const row = db.prepare('SELECT file_id, updated_at FROM qr WHERE id = 1').get();
  return row || null;
}

function addPendingScreenshot({ userId, username, fileId }) {
  const now = new Date().toISOString();
  const result = db.prepare(`
    INSERT INTO pending_screenshots (user_id, username, file_id, status, created_at)
    VALUES (?, ?, ?, 'pending', ?)
  `).run(userId, username || null, fileId, now);
  return result.lastInsertRowid;
}

function setAdminMessageId(screenshotId, adminMessageId) {
  db.prepare(`
    UPDATE pending_screenshots SET admin_message_id = ? WHERE id = ?
  `).run(adminMessageId, screenshotId);
}

function getScreenshotById(screenshotId) {
  return db.prepare('SELECT * FROM pending_screenshots WHERE id = ?').get(screenshotId);
}

function markConfirmed(screenshotId) {
  db.prepare(`
    UPDATE pending_screenshots SET status = 'confirmed' WHERE id = ?
  `).run(screenshotId);
}

module.exports = {
  setQr,
  getQr,
  addPendingScreenshot,
  setAdminMessageId,
  getScreenshotById,
  markConfirmed,
};
