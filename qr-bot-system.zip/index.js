// index.js
// Single process running TWO Telegram bots:
//   BOT1 (user-facing): /start -> Get QR button -> latest QR + "send screenshot" prompt
//                        user sends photo -> forwarded to admin (BOT2) for confirmation
//   BOT2 (admin-facing): owner can upload a new QR anytime (replaces old one)
//                        receives screenshots with a "Done" button -> confirming notifies BOT1 user
//
// Required env vars:
//   BOT1_TOKEN   - token for the user-facing bot
//   BOT2_TOKEN   - token for the admin-facing bot
//   ADMIN_ID     - Telegram numeric user ID of the bot2 owner/admin (only they can upload QR / confirm)

require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const db = require('./db');

const BOT1_TOKEN = process.env.BOT1_TOKEN;
const BOT2_TOKEN = process.env.BOT2_TOKEN;
const ADMIN_ID = process.env.ADMIN_ID ? Number(process.env.ADMIN_ID) : null;

if (!BOT1_TOKEN || !BOT2_TOKEN) {
  console.error('Missing BOT1_TOKEN or BOT2_TOKEN in environment variables.');
  process.exit(1);
}
if (!ADMIN_ID) {
  console.error('Missing ADMIN_ID in environment variables.');
  process.exit(1);
}

const bot1 = new TelegramBot(BOT1_TOKEN, { polling: true });
const bot2 = new TelegramBot(BOT2_TOKEN, { polling: true });

console.log('Bot1 (user bot) and Bot2 (admin bot) are starting...');

// In-memory flag: is admin currently in "upload new QR" mode?
let awaitingNewQr = {}; // { [adminId]: true }

// ---------------------------
// BOT 1: USER-FACING BOT
// ---------------------------

bot1.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  bot1.sendMessage(chatId, 'Welcome! Tap the button below to get the payment QR.', {
    reply_markup: {
      inline_keyboard: [[{ text: '📷 Get QR', callback_data: 'get_qr' }]],
    },
  });
});

bot1.on('callback_query', async (query) => {
  if (query.data === 'get_qr') {
    const chatId = query.message.chat.id;
    const qr = db.getQr();

    if (!qr) {
      await bot1.answerCallbackQuery(query.id);
      return bot1.sendMessage(chatId, 'QR is not available right now. Please try again later.');
    }

    await bot1.answerCallbackQuery(query.id);
    await bot1.sendPhoto(chatId, qr.file_id, {
      caption: 'Scan this QR to pay.\n\nAfter payment, please send a screenshot here as proof.',
    });
  }
});

// User sends a photo (payment screenshot) -> forward to admin bot for confirmation
bot1.on('photo', async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const username = msg.from.username || msg.from.first_name || 'Unknown';
  const fileId = msg.photo[msg.photo.length - 1].file_id; // highest resolution

  // Store as pending screenshot
  const screenshotId = db.addPendingScreenshot({ userId, username, fileId });

  // Notify user
  await bot1.sendMessage(chatId, 'Screenshot received! Please wait for admin confirmation.');

  // Forward to admin bot with a "Done" button
  try {
    const sentMsg = await bot2.sendPhoto(ADMIN_ID, fileId, {
      caption: `New payment screenshot\nFrom: @${username} (ID: ${userId})\nScreenshot ID: ${screenshotId}`,
      reply_markup: {
        inline_keyboard: [[{ text: '✅ Done', callback_data: `confirm_${screenshotId}` }]],
      },
    });
    db.setAdminMessageId(screenshotId, sentMsg.message_id);
  } catch (err) {
    console.error('Failed to forward screenshot to admin:', err.message);
  }
});

// ---------------------------
// BOT 2: ADMIN-FACING BOT
// ---------------------------

bot2.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  if (chatId !== ADMIN_ID) {
    return bot2.sendMessage(chatId, 'You are not authorized to use this bot.');
  }
  bot2.sendMessage(chatId, 'Admin panel ready.', {
    reply_markup: {
      inline_keyboard: [[{ text: '🔄 Upload New QR', callback_data: 'upload_qr' }]],
    },
  });
});

bot2.onText(/\/setqr/, (msg) => {
  const chatId = msg.chat.id;
  if (chatId !== ADMIN_ID) return;
  awaitingNewQr[chatId] = true;
  bot2.sendMessage(chatId, 'Please send the new QR image now.');
});

bot2.on('callback_query', async (query) => {
  const chatId = query.message.chat.id;

  if (chatId !== ADMIN_ID) {
    return bot2.answerCallbackQuery(query.id, { text: 'Not authorized.' });
  }

  if (query.data === 'upload_qr') {
    awaitingNewQr[chatId] = true;
    await bot2.answerCallbackQuery(query.id);
    return bot2.sendMessage(chatId, 'Please send the new QR image now.');
  }

  if (query.data.startsWith('confirm_')) {
    const screenshotId = Number(query.data.split('_')[1]);
    const screenshot = db.getScreenshotById(screenshotId);

    if (!screenshot) {
      return bot2.answerCallbackQuery(query.id, { text: 'Not found.' });
    }
    if (screenshot.status === 'confirmed') {
      return bot2.answerCallbackQuery(query.id, { text: 'Already confirmed.' });
    }

    db.markConfirmed(screenshotId);
    await bot2.answerCallbackQuery(query.id, { text: 'Confirmed!' });

    // Edit admin's message to show it's done
    try {
      await bot2.editMessageCaption(
        `${query.message.caption}\n\n✅ Confirmed`,
        { chat_id: chatId, message_id: query.message.message_id }
      );
    } catch (err) {
      console.error('Failed to edit admin caption:', err.message);
    }

    // Notify the user on bot1
    try {
      await bot1.sendMessage(screenshot.user_id, '✅ Your payment screenshot has been confirmed by the admin!');
    } catch (err) {
      console.error('Failed to notify user on bot1:', err.message);
    }
  }
});

// Admin sends a photo -> if in "awaiting new QR" mode, save it as the new QR
bot2.on('photo', async (msg) => {
  const chatId = msg.chat.id;
  if (chatId !== ADMIN_ID) return;

  if (awaitingNewQr[chatId]) {
    const fileId = msg.photo[msg.photo.length - 1].file_id;
    db.setQr(fileId);
    awaitingNewQr[chatId] = false;
    await bot2.sendMessage(chatId, '✅ QR updated successfully! Users will now receive this new QR.');
  }
});

// ---------------------------
// Error handling
// ---------------------------

bot1.on('polling_error', (err) => console.error('Bot1 polling error:', err.message));
bot2.on('polling_error', (err) => console.error('Bot2 polling error:', err.message));

console.log('Both bots are running.');
