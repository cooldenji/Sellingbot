# QR Payment Verification Bot System

Single Node.js process running two Telegram bots:

- **Bot1 (User bot):** `/start` → "Get QR" button → sends latest QR + asks for screenshot. User sends screenshot → it goes to admin (Bot2) for confirmation.
- **Bot2 (Admin bot):** Owner can upload a new QR anytime (`/setqr` or "Upload New QR" button). Receives screenshots with a "Done" button — clicking it notifies the user on Bot1 that their payment is confirmed.

## Files

- `index.js` — both bot instances + all logic
- `db.js` — SQLite storage (latest QR, pending screenshots)
- `package.json` — dependencies
- `.env.example` — sample env vars

## Local Setup

```bash
npm install
cp .env.example .env
# edit .env and fill in your tokens + admin ID
npm start
```

## Getting your values

- **BOT1_TOKEN / BOT2_TOKEN:** Create two bots via [@BotFather](https://t.me/BotFather), get each token.
- **ADMIN_ID:** Your numeric Telegram user ID. Get it by messaging [@userinfobot](https://t.me/userinfobot).

## How it works

1. You (admin) message Bot2 with `/start`, tap "Upload New QR", send a QR image. It's saved in `data.db`.
2. Any user messages Bot1 with `/start`, taps "Get QR", receives the QR + a prompt to send a screenshot.
3. User sends a screenshot photo to Bot1 → it's forwarded to you on Bot2 with a "Done" button.
4. You tap "Done" → the user automatically gets a "confirmed" message on Bot1.
5. To change the QR later, just message Bot2 again with `/setqr` or the button — it overwrites the old one.

## Deploying to Render

1. Push this folder to a GitHub repo (don't commit `.env` or `data.db` — already in `.gitignore`).
2. On Render: New → Web Service → connect your repo.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variables in Render dashboard: `BOT1_TOKEN`, `BOT2_TOKEN`, `ADMIN_ID`
6. Deploy.

### Important note about Render's free tier

Render's free web services use an **ephemeral disk** — meaning the `data.db` SQLite file gets wiped on every redeploy, and possibly after the service sleeps from inactivity and restarts. This means:

- After every redeploy/restart, you'll need to re-upload the QR via Bot2 (`/setqr`).
- Pending/unconfirmed screenshots will also be lost on restart.

This is fine for your use case since you said you'll just re-upload QR when needed — just keep it in mind so you're not confused if QR "disappears" after a redeploy.

**If you want this to survive restarts without re-uploading:** either upgrade to Render's paid plan with a persistent disk add-on, or switch storage to MongoDB Atlas free tier later (the `db.js` module is small and isolated, so swapping it out later is straightforward).

### Background worker vs web service

Since these bots use polling (not webhooks), Render's **Background Worker** service type is actually a better fit than "Web Service" (no need to expose a port). If you only have Web Service available on your plan, that also works fine — the bots just need to be running and polling, they don't need to receive HTTP traffic.

## Notes

- Only `ADMIN_ID` can use Bot2's commands/buttons — everyone else gets "Not authorized."
- `better-sqlite3` is a native module; Render's build environment compiles it automatically during `npm install`. No extra setup needed.
