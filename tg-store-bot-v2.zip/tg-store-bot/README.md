# 🛒 TgApiStore Bot v2.0

A professional Telegram digital-goods store with **User Bot** + **Admin Bot**.

---

## ✨ What's New in v2.0

| Feature | Status |
|---|---|
| Deposit request → full user details + screenshot + Approve/Reject + Message User button | ✅ |
| Product buy (manual delivery) → admin gets full order details + Approve/Reject + Message User | ✅ |
| User sees "Please wait for admin approval" on both deposit & manual buy | ✅ |
| Admin can directly Message any user from approval cards | ✅ |
| 📢 Broadcast to ALL users (Owner only) | ✅ |
| 👥 View all users + count + recent joins (Owner only) | ✅ |
| Colourful emoji buttons throughout | ✅ |
| QR system for UPI + Binance (upload in Admin Bot) | ✅ |
| Cloudflare / VPS hostable Node.js code | ✅ |

---

## 📁 Folder Structure

```
tg-store-bot/
├── admin-bot/
│   └── index.js        ← Admin Bot (owner + hired admins)
├── user-bot/
│   └── index.js        ← User Bot (public-facing store)
├── shared/
│   ├── db.js           ← JSON file database (shared between both bots)
│   └── helpers.js      ← Utility functions
├── data/               ← Auto-created: products.json, users.json, etc.
├── .env.example        ← Copy to .env and fill in values
└── package.json
```

---

## ⚙️ Setup (Local / VPS)

### 1. Create Two Bots via @BotFather

- **User Bot** → for customers
- **Admin Bot** → private, only you and hired admins

### 2. Get Your Telegram User ID

Message [@userinfobot](https://t.me/userinfobot) — copy your numeric ID.

### 3. Configure `.env`

```bash
cp .env.example .env
nano .env
```

Fill in:

```env
BOT_TOKEN=your_user_bot_token
ADMIN_BOT_TOKEN=your_admin_bot_token
OWNER_ID=your_numeric_telegram_id
ADMIN_PASSWORD=your_secret_password
ADMIN_NOTIFY_CHAT_ID=your_numeric_telegram_id
```

> `ADMIN_NOTIFY_CHAT_ID` = your own Telegram ID (same as OWNER_ID usually).
> This is where the Admin Bot pushes deposit/buy approval cards.

### 4. Install & Run

```bash
npm install
npm start          # starts both bots
# OR separately:
npm run start:user
npm run start:admin
```

---

## ☁️ Hosting on Cloudflare (Recommended)

Cloudflare Workers don't support long-running Node.js processes. Instead, use **Cloudflare Tunnel** with a small VM, or deploy on one of these platforms:

### Option A — Railway.app (easiest, free tier)

1. Push your code to a GitHub repo (no `.env` — use Railway's env vars panel)
2. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
3. Add env vars in the Railway dashboard
4. Railway runs `npm start` automatically

### Option B — Render.com

1. Connect your GitHub repo at [render.com](https://render.com)
2. Set Build Command: `npm install`
3. Set Start Command: `npm start`
4. Add env vars in the Environment tab

### Option C — VPS (DigitalOcean / Hetzner / Contabo)

```bash
# On your VPS
git clone <your-repo>
cd tg-store-bot
cp .env.example .env && nano .env   # fill in values
npm install
npm install -g pm2
pm2 start "npm run start:user" --name user-bot
pm2 start "npm run start:admin" --name admin-bot
pm2 save && pm2 startup
```

### Option D — Cloudflare Tunnel (existing server)

```bash
# Install cloudflared on your server
# This keeps your bots running behind Cloudflare without opening ports
cloudflared tunnel --no-autoupdate run
```

> **Note:** The bots use **long-polling** (not webhooks), so they don't need an open port.
> Any VPS or container platform works fine.

---

## 🤖 Admin Bot Features

| Button | What it does |
|---|---|
| ➕ Add Product | Multi-step: choose delivery type, upload file/text, set name/price/stock |
| 📦 Products | List, toggle active/hidden, add stock, delete |
| 📊 Statistics | Revenue, users, orders, deposits summary |
| 🔗 Link System | Set channel, group, support, UPI ID, Binance ID, USDT rate |
| 📁 Session Bookings | View pending manual-delivery orders |
| 🧾 Pending Deposits | View + Approve/Reject with screenshot, full user info, Message User |
| 🖼️ Upload QR Codes | Upload UPI QR and Binance QR images |
| 🚫 Ban/Restrict | Ban/unban users by ID |
| 👮 Manage Admins | Add (`/admin <id>`) and remove hired admins |
| 📢 Broadcast | Send message to ALL users (owner only) |
| 👥 View All Users | Total count + recent joins + banned count (owner only) |

---

## 💬 Deposit Approval Flow

1. User deposits → uploads screenshot in User Bot
2. Admin Bot receives a card with:
   - Screenshot (photo)
   - User: @username (ID: `12345`)
   - Name, Member Since, Total Purchases
   - Method, Amount, Previous Balance, Ref ID
   - **✅ Approve** | **❌ Reject** | **💬 Message User** buttons
3. Admin taps Approve → user's balance is credited + user gets notified
4. Admin taps Message User → can type a direct message to that user

---

## 🛒 Product Buy Approval Flow (Manual Delivery)

1. User buys a "manual delivery" product
2. User sees: _"Your product is ready! Please wait for admin approval."_
3. Admin Bot receives a card with:
   - User details (name, ID, join date, past purchases)
   - Product name, qty, amount paid, order ID
   - **✅ Approve & Deliver** | **❌ Reject & Refund** | **💬 Message User** buttons
4. Approve → user notified; Reject → balance refunded + user notified

---

## 📢 Broadcast

Owner only. Admin Panel → 📢 Broadcast → type message → sent to every user who has ever started the User Bot.

---

## 🔑 Admin Commands

```
/start      → login to admin panel
/admin <id> → add a hired admin by Telegram ID or @username
```

---

## 🗂️ Data Storage

All data is stored as JSON files in `data/`:

| File | Contents |
|---|---|
| `products.json` | All products (name, price, stock, delivery type) |
| `users.json` | All users (balance, purchases, referrals) |
| `deposits.json` | All deposit requests (pending/approved/rejected) |
| `orders.json` | All orders |
| `settings.json` | UPI ID, QR file IDs, channel links, etc. |
| `admins.json` | Owner and hired admins |
| `bans.json` | Banned users |

> Back up the `data/` folder regularly on VPS deployments.
> On Railway/Render use a persistent volume or switch to SQLite for production.
