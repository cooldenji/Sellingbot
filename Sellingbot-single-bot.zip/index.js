const http = require('http');
const { initDB } = require('./database');

async function main() {
  console.log('🚀 Initializing database...');
  await initDB();

  console.log('🤖 Starting Bot (User + Admin combined)...');
  require('./bot');

  console.log('✅ Bot is running!');

  const PORT = process.env.PORT || 3000;
  http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('Zed Zoee Bot is running ✅');
  }).listen(PORT, () => {
    console.log(`🌐 Health check server on port ${PORT}`);
  });
}

main().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
