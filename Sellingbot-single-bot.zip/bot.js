const TelegramBot = require('node-telegram-bot-api');
const config = require('./config');
const db = require('./database');
const utils = require('./utils');

// ✅ SINGLE BOT — User aur Admin dono isi ek bot/token se chalte hain
const bot = new TelegramBot(config.BOT_TOKEN, { polling: true });

const userState = {};
const authenticatedAdmins = new Set(); // in-memory cache (DB se bhi backed hai, restart-proof)

function getState(userId) {
  if (!userState[userId]) userState[userId] = {};
  return userState[userId];
}

function clearState(userId) {
  userState[userId] = {};
}

function isOwner(userId) {
  return userId === config.OWNER_ID;
}

async function isAdminAuthenticated(userId) {
  if (authenticatedAdmins.has(userId)) return true;
  const saved = await db.getSetting(`admin_auth_${userId}`);
  if (saved === '1') {
    authenticatedAdmins.add(userId);
    return true;
  }
  return false;
}

async function setAdminAuthenticated(userId) {
  authenticatedAdmins.add(userId);
  await db.setSetting(`admin_auth_${userId}`, '1');
}

function backBtn(label = '« Back to Menu', data = 'adm_menu') {
  return { inline_keyboard: [[{ text: label, callback_data: data }]] };
}

// ════════════════════════════════════════════════════════════════════════════
// ─── /start ───────────────────────────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════════════════
bot.onText(/\/start(?:\s+(.+))?/, async (msg, match) => {
  const userId = msg.from.id;
  const username = msg.from.username || '';
  const firstName = msg.from.first_name || '';
  const lastName = msg.from.last_name || '';
  const fullName = (firstName + ' ' + lastName).trim();

  const banned = await utils.isUserBanned(userId);
  if (banned) {
    await bot.sendMessage(userId,
      '🚫 *Your account has been suspended.*\n\nContact support if you think this is an error.',
      { parse_mode: 'Markdown' }
    );
    return;
  }

  let referredBy = null;
  const arg = match && match[1];
  if (arg && arg.startsWith('ref_')) {
    const refUid = parseInt(arg.replace('ref_', ''));
    if (refUid && refUid !== userId) referredBy = refUid;
  }

  let dbUser = await db.getUser(userId);
  if (!dbUser) {
    await db.createUser(userId, username, fullName, referredBy);
    dbUser = await db.getUser(userId);
  }

  if (!dbUser.terms_accepted) {
    await sendTermsMessage(userId);
    return;
  }

  clearState(userId);
  await showMainMenu(userId);
});

// ─── /admin — Admin Panel Entry ───────────────────────────────────────────────
bot.onText(/\/admin/, async (msg) => {
  const userId = msg.from.id;
  if (!isOwner(userId)) {
    await bot.sendMessage(userId, '🚫 *Unauthorized.*', { parse_mode: 'Markdown' });
    return;
  }

  if (await isAdminAuthenticated(userId)) {
    await showAdminMenu(userId);
    return;
  }

  getState(userId).waitingAdminPassword = true;
  await bot.sendMessage(userId,
    `🔐 *Admin Panel*\n\nEnter your password to continue:`,
    { parse_mode: 'Markdown' }
  );
});

// ─── Terms Message ────────────────────────────────────────────────────────────
async function sendTermsMessage(userId) {
  const groupLink = await db.getSetting('group_link') || config.GROUP_LINK;
  const channelLink = await db.getSetting('channel_link') || config.CHANNEL_LINK;
  const botName = await db.getSetting('bot_name') || config.BOT_NAME;

  const text =
    `👋 *Welcome to ${botName}!* ✨\n\n` +
    `Before you begin, please complete these 2 steps:\n\n` +
    `*📌 Step 1 — Read Our Rules:*\n` +
    `🔸 Products are sold as-is — keep your files secure\n` +
    `🔸 Login one account at a time, wait 2–3 min between each\n` +
    `🔸 No spam or mass messaging — misuse may freeze accounts\n` +
    `🔸 Failed OTPs are auto-refunded to your wallet\n` +
    `🔸 One account per person — fake referrals void rewards\n\n` +
    `*📌 Step 2 — Join Our Community:*\n` +
    `Tap the buttons below to join, then accept terms.`;

  await bot.sendMessage(userId, text, {
    parse_mode: 'Markdown',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '📢 Join Channel', url: channelLink },
          { text: '👥 Join Group', url: groupLink }
        ],
        [{ text: '📋 View & Accept Terms', callback_data: 'show_terms' }]
      ]
    }
  });
}

// ─── Terms Detail ─────────────────────────────────────────────────────────────
async function sendTermsDetail(userId, messageId) {
  const text =
    `📋 *Terms & Conditions*\n\n` +
    `By using this bot, you agree to the following:\n\n` +
    `🔒 *Products:* Sold as-is. Keep files secure, never share.\n\n` +
    `⏰ *Usage:* One account at a time. Wait 2–3 mins between logins.\n\n` +
    `🚫 *Abuse:* No spam or mass messaging. Misuse is your responsibility.\n\n` +
    `💰 *Refunds:* Only as described at purchase. Failed OTPs are auto-refunded.\n\n` +
    `🎁 *Referrals:* One genuine account per person. Fake referrals void all rewards.\n\n` +
    `Do you accept these terms?`;

  await bot.editMessageText(text, {
    chat_id: userId,
    message_id: messageId,
    parse_mode: 'Markdown',
    reply_markup: {
      inline_keyboard: [
        [{ text: '✅ I Accept — Continue', callback_data: 'accept_terms' }],
        [{ text: '❌ Decline', callback_data: 'decline_terms' }]
      ]
    }
  });
}

// ─── Main Menu ────────────────────────────────────────────────────────────────
async function showMainMenu(userId, messageId) {
  const refEnabled = await db.getSetting('referral_enabled') === '1';
  const refReward = await db.getSetting('referral_reward_inr') || '10';
  const me = await bot.getMe();
  const refLink = `https://t.me/${me.username}?start=ref_${userId}`;

  let text = `🏠 *Main Menu*\n\nSelect an option below to get started. 👇`;

  if (refEnabled) {
    text =
      `🎁 *Earn While You Share!*\n` +
      `Invite friends and earn *Rs ${refReward}* per successful referral.\n` +
      `🔗 Your Link: \`${refLink}\`\n\n` +
      `🏠 *Main Menu* — Select an option: 👇`;
  }

  const keyboard = utils.getMainMenuKeyboard();

  if (messageId) {
    try {
      await bot.editMessageText(text, {
        chat_id: userId,
        message_id: messageId,
        parse_mode: 'Markdown',
        reply_markup: keyboard
      });
    } catch {
      await bot.sendMessage(userId, text, { parse_mode: 'Markdown', reply_markup: keyboard });
    }
  } else {
    await bot.sendMessage(userId, text, { parse_mode: 'Markdown', reply_markup: keyboard });
  }
}

// ════════════════════════════════════════════════════════════════════════════
// ─── Callback Query Handler (USER + ADMIN dono) ──────────────────────────────
// ════════════════════════════════════════════════════════════════════════════
bot.on('callback_query', async (query) => {
  const userId = query.from.id;
  const data = query.data;
  const messageId = query.message.message_id;

  try { await bot.answerCallbackQuery(query.id); } catch {}

  // ─── Admin callbacks (adm_ prefix) — route to admin handler ──────────────
  if (data.startsWith('adm_') || data === 'noop') {
    if (!isOwner(userId) || !(await isAdminAuthenticated(userId))) {
      await bot.sendMessage(userId, '🚫 Please /admin and authenticate first.');
      return;
    }
    await handleAdminCallback(userId, data, messageId);
    return;
  }

  // ─── User callbacks ────────────────────────────────────────────────────────
  const banned = await utils.isUserBanned(userId);
  if (banned) {
    await bot.sendMessage(userId, '🚫 *Your account has been suspended.*', { parse_mode: 'Markdown' });
    return;
  }

  try {
    if (data === 'show_terms') {
      await sendTermsDetail(userId, messageId);
    } else if (data === 'accept_terms') {
      await handleAcceptTerms(userId, messageId);
    } else if (data === 'decline_terms') {
      await bot.editMessageText(
        '❌ You must accept the terms to use this bot.\n\nSend /start to try again.',
        { chat_id: userId, message_id: messageId }
      );
    } else if (data === 'main_menu') {
      await showMainMenu(userId, messageId);
    } else if (data === 'buy_product') {
      await showProducts(userId, messageId);
    } else if (data === 'profile') {
      await showProfile(userId, messageId);
    } else if (data === 'deposit') {
      await showDepositMenu(userId, messageId);
    } else if (data === 'refer_earn') {
      await showReferral(userId, messageId);
    } else if (data === 'support') {
      await showSupport(userId, messageId);
    } else if (data.startsWith('buy_item_')) {
      const productId = parseInt(data.replace('buy_item_', ''));
      await showPurchaseConfirm(userId, messageId, productId);
    } else if (data.startsWith('confirm_buy_')) {
      const productId = parseInt(data.replace('confirm_buy_', ''));
      await processPurchase(userId, messageId, productId);
    } else if (data === 'deposit_upi') {
      await showUpiOptions(userId, messageId);
    } else if (data === 'deposit_bnb') {
      await showBnbDeposit(userId, messageId);
    } else if (data.startsWith('upi_app_')) {
      const app = data.replace('upi_app_', '');
      getState(userId).upiApp = app;
      await askDepositAmount(userId, messageId, app);
    } else if (data === 'i_have_paid') {
      await askPaymentScreenshot(userId, messageId);
    } else if (data === 'cancel_deposit') {
      clearState(userId);
      await bot.editMessageText('❌ Deposit cancelled.', {
        chat_id: userId,
        message_id: messageId,
        reply_markup: utils.getBackKeyboard()
      });
    }
  } catch (err) {
    console.error('User callback error:', err.message);
  }
});

// ─── Accept Terms ─────────────────────────────────────────────────────────────
async function handleAcceptTerms(userId, messageId) {
  const database = await db.getDB();
  await database.run('UPDATE users SET terms_accepted = 1 WHERE user_id = ?', userId);

  const dbUser = await db.getUser(userId);

  if (dbUser && dbUser.referred_by) {
    const refEnabled = await db.getSetting('referral_enabled') === '1';
    if (refEnabled) {
      const reward = parseFloat(await db.getSetting('referral_reward_inr')) || 10;
      await database.run(
        `UPDATE users SET balance_inr = balance_inr + ?, referral_earned = referral_earned + ?, referral_count = referral_count + 1 WHERE user_id = ?`,
        reward, reward, dbUser.referred_by
      );
      try {
        await bot.sendMessage(dbUser.referred_by,
          `🎁 *Referral Reward!*\n\nSomeone joined using your link!\n✅ *Rs ${reward.toFixed(0)}* added to your wallet.`,
          { parse_mode: 'Markdown' }
        );
      } catch {}
    }
  }

  await bot.editMessageText(
    `✅ *Welcome aboard!* 🎉\n\nTerms accepted. You're all set!`,
    { chat_id: userId, message_id: messageId, parse_mode: 'Markdown' }
  );

  await showMainMenu(userId);
}

// ─── Products ─────────────────────────────────────────────────────────────────
async function showProducts(userId, messageId) {
  const products = await db.getActiveProducts();
  const rate = parseFloat(await db.getSetting('usdt_to_inr_rate')) || 90;

  if (!products.length) {
    await bot.editMessageText(
      `📦 *No Products Available*\n\nCheck back soon — new stock is being added. 🔄`,
      { chat_id: userId, message_id: messageId, parse_mode: 'Markdown', reply_markup: utils.getBackKeyboard() }
    );
    return;
  }

  let text = `🛍️ *Available Products*\n💱 Rate: 1 USDT = Rs ${rate.toFixed(1)}\n\n`;
  const keyboard = [];

  for (const p of products) {
    const usdt = await utils.inrToUsdt(p.price_inr);
    text += `📦 *${p.name}*\n`;
    text += `   💰 Rs ${p.price_inr.toFixed(0)} ($${usdt.toFixed(2)})\n`;
    text += `   📊 Stock: ${p.stock} available\n\n`;
    keyboard.push([{ text: `🛒 ${p.name} — Rs ${p.price_inr.toFixed(0)}`, callback_data: `buy_item_${p.id}` }]);
  }

  keyboard.push([{ text: '🏠 Back to Menu', callback_data: 'main_menu' }]);

  await bot.editMessageText(text, {
    chat_id: userId,
    message_id: messageId,
    parse_mode: 'Markdown',
    reply_markup: { inline_keyboard: keyboard }
  });
}

// ─── Purchase Confirm ─────────────────────────────────────────────────────────
async function showPurchaseConfirm(userId, messageId, productId) {
  const database = await db.getDB();
  const product = await database.get('SELECT * FROM products WHERE id = ? AND is_active = 1', productId);

  if (!product) {
    await bot.editMessageText('❌ Product not found.',
      { chat_id: userId, message_id: messageId, reply_markup: utils.getBackKeyboard('buy_product') }
    );
    return;
  }

  const dbUser = await db.getUser(userId);
  const balance = dbUser.balance_inr;
  const price = product.price_inr;
  const usdtPrice = await utils.inrToUsdt(price);
  const usdtBalance = await utils.inrToUsdt(balance);
  const canBuy = balance >= price && product.stock > 0;
  const stockStatus = product.stock > 0 ? `✅ ${product.stock} in stock` : '❌ Out of stock';
  const balanceStatus = balance >= price ? '✅ Sufficient balance' : '⚠️ Insufficient balance';

  const text =
    `🛒 *Purchase Confirmation*\n\n` +
    `📦 *${product.name}*\n` +
    `${product.description || ''}\n\n` +
    `💰 *Price:* Rs ${price.toFixed(0)} ($${usdtPrice.toFixed(2)})\n` +
    `💵 *Your Balance:* Rs ${balance.toFixed(0)} ($${usdtBalance.toFixed(2)})\n` +
    `📊 *Stock:* ${stockStatus}\n` +
    `${balanceStatus}\n\n` +
    `⚠️ Please use Telegram X for best experience.\n` +
    `🚫 We are not responsible for any freeze/ban after delivery.`;

  const keyboard = [];
  if (canBuy) {
    keyboard.push([{ text: '✅ Confirm Purchase', callback_data: `confirm_buy_${productId}` }]);
  } else if (balance < price) {
    keyboard.push([{ text: '💰 Add Funds', callback_data: 'deposit' }]);
  }
  keyboard.push([
    { text: '« Back', callback_data: 'buy_product' },
    { text: '🏠 Menu', callback_data: 'main_menu' }
  ]);

  await bot.editMessageText(text, {
    chat_id: userId,
    message_id: messageId,
    parse_mode: 'Markdown',
    reply_markup: { inline_keyboard: keyboard }
  });
}

// ─── Process Purchase ─────────────────────────────────────────────────────────
async function processPurchase(userId, messageId, productId) {
  const database = await db.getDB();
  const product = await database.get(
    'SELECT * FROM products WHERE id = ? AND stock > 0 AND is_active = 1', productId
  );

  if (!product) {
    await bot.editMessageText('❌ Out of stock! Please choose another product.',
      { chat_id: userId, message_id: messageId, reply_markup: utils.getBackKeyboard('buy_product') }
    );
    return;
  }

  const dbUser = await db.getUser(userId);
  if (dbUser.balance_inr < product.price_inr) {
    await bot.editMessageText('❌ Insufficient balance. Please add funds first.',
      { chat_id: userId, message_id: messageId, reply_markup: utils.getBackKeyboard('deposit') }
    );
    return;
  }

  await db.deductUserBalance(userId, product.price_inr);
  await database.run(
    'UPDATE products SET stock = stock - 1, total_sold = total_sold + 1 WHERE id = ?', productId
  );

  const purchaseResult = await database.run(
    'INSERT INTO purchases (user_id, product_id, amount_inr, content_delivered) VALUES (?, ?, ?, ?)',
    userId, productId, product.price_inr, product.content
  );
  const purchaseId = purchaseResult.lastID;

  await bot.editMessageText(
    `⏳ *Order Placed!* 🎉\n\n` +
    `📦 *${product.name}*\n\n` +
    `✅ Your order has been placed successfully.\n` +
    `🕐 Please wait a few minutes for admin confirmation.\n\n` +
    `Your product will be delivered shortly!`,
    { chat_id: userId, message_id: messageId, parse_mode: 'Markdown', reply_markup: utils.getBackKeyboard() }
  );

  // ✅ Admin ko notify karo — SAME BOT hai, isliye direct bot.sendMessage (no cross-bot relay needed)
  try {
    const usdtPrice = await utils.inrToUsdt(product.price_inr);
    const balanceAfter = dbUser.balance_inr - product.price_inr;

    const adminText =
      `🛒 *New Purchase Request!*\n\n` +
      `👤 *User:* ${dbUser.full_name}\n` +
      `📱 *Username:* @${dbUser.username || 'N/A'}\n` +
      `🆔 *User ID:* \`${userId}\`\n\n` +
      `📦 *Product:* ${product.name}\n` +
      `💰 *Amount:* Rs ${product.price_inr.toFixed(0)} ($${usdtPrice.toFixed(2)})\n` +
      `💵 *Balance After:* Rs ${balanceAfter.toFixed(0)}\n` +
      `🆔 *Purchase ID:* \`${purchaseId}\``;

    await bot.sendMessage(config.OWNER_ID, adminText, {
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '✅ Approve & Deliver', callback_data: `adm_deliver_${purchaseId}` },
            { text: '❌ Dismiss & Refund', callback_data: `adm_refund_${purchaseId}` }
          ],
          [{ text: '💬 Message User', callback_data: `adm_msg_${userId}` }]
        ]
      }
    });
  } catch (err) {
    console.error('Admin purchase notify failed:', err.message);
  }
}

// ─── Profile ──────────────────────────────────────────────────────────────────
async function showProfile(userId, messageId) {
  const u = await db.getUser(userId);
  if (!u) return;

  const balanceUsdt = await utils.inrToUsdt(u.balance_inr);
  const depositedUsdt = await utils.inrToUsdt(u.total_deposited);
  const spentUsdt = await utils.inrToUsdt(u.total_spent);
  const earnedUsdt = await utils.inrToUsdt(u.referral_earned);
  const refReward = await db.getSetting('referral_reward_inr') || '10';
  const me = await bot.getMe();

  const text =
    `👤 *Your Profile*\n\n` +
    `*🪪 Account*\n` +
    `Name: ${u.full_name}\n` +
    `ID: \`${u.user_id}\`\n` +
    `Joined: ${utils.formatDateTime(u.joined_at)}\n\n` +
    `*💼 Wallet*\n` +
    `Balance: Rs ${u.balance_inr.toFixed(0)} ($${balanceUsdt.toFixed(2)})\n` +
    `Deposited: Rs ${u.total_deposited.toFixed(0)} ($${depositedUsdt.toFixed(2)})\n` +
    `Spent: Rs ${u.total_spent.toFixed(0)} ($${spentUsdt.toFixed(2)})\n` +
    `Purchases: ${u.total_purchases}\n\n` +
    `*🎁 Referrals*\n` +
    `Referrals: ${u.referral_count}\n` +
    `Earned: Rs ${u.referral_earned.toFixed(0)} ($${earnedUsdt.toFixed(2)})\n` +
    `Reward: Rs ${refReward} per referral\n\n` +
    `*🔗 Your Referral Link:*\n` +
    `\`https://t.me/${me.username}?start=ref_${userId}\``;

  await bot.editMessageText(text, {
    chat_id: userId,
    message_id: messageId,
    parse_mode: 'Markdown',
    reply_markup: utils.getBackKeyboard()
  });
}

// ─── Deposit Menu ─────────────────────────────────────────────────────────────
async function showDepositMenu(userId, messageId) {
  const upiOn = await db.getSetting('upi_enabled') === '1';
  const bnbOn = await db.getSetting('bnb_enabled') === '1';
  const fampayOn = await db.getSetting('fampay_enabled') === '1';
  const minDep = await db.getSetting('min_deposit_inr') || '20';

  const keyboard = [];
  if (upiOn || fampayOn) keyboard.push([{ text: '📱 UPI Payment', callback_data: 'deposit_upi' }]);
  if (bnbOn) keyboard.push([{ text: '🟡 USDT via BNB Smart Chain (BEP20)', callback_data: 'deposit_bnb' }]);

  if (keyboard.length === 0) {
    await bot.editMessageText(
      `⚠️ *No Payment Methods Available*\n\nPlease contact support for assistance.`,
      { chat_id: userId, message_id: messageId, parse_mode: 'Markdown', reply_markup: utils.getBackKeyboard() }
    );
    return;
  }

  keyboard.push([{ text: '🏠 Back to Menu', callback_data: 'main_menu' }]);

  await bot.editMessageText(
    `💰 *Add Funds*\n\nMinimum deposit: *Rs ${minDep}*\n\nSelect your payment method: 👇`,
    { chat_id: userId, message_id: messageId, parse_mode: 'Markdown', reply_markup: { inline_keyboard: keyboard } }
  );
}

// ─── UPI Options ──────────────────────────────────────────────────────────────
async function showUpiOptions(userId, messageId) {
  const minDep = await db.getSetting('min_deposit_inr') || '20';

  await bot.editMessageText(
    `📱 *UPI Payment*\n\n✅ Minimum: Rs ${minDep}\n⚠️ Verified manually after screenshot.\n\n*Select your UPI app:* 👇`,
    {
      chat_id: userId,
      message_id: messageId,
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '📱 GPay', callback_data: 'upi_app_gpay' },
            { text: '💳 FamPay', callback_data: 'upi_app_fampay' },
            { text: '📲 Any UPI', callback_data: 'upi_app_any' }
          ],
          [{ text: '« Back', callback_data: 'deposit' }]
        ]
      }
    }
  );
}

// ─── Ask Deposit Amount ───────────────────────────────────────────────────────
async function askDepositAmount(userId, messageId, upiApp) {
  const minDep = await db.getSetting('min_deposit_inr') || '20';
  const appNames = { gpay: 'GPay', fampay: 'FamPay', any: 'Any UPI' };
  const appName = appNames[upiApp] || 'UPI';

  const state = getState(userId);
  state.waitingDepositAmount = true;
  state.upiApp = upiApp;

  await bot.editMessageText(
    `📱 *${appName} Payment*\n\nMinimum amount: *Rs ${minDep}*\n\nPlease type the amount you want to deposit (in Rs): ✍️`,
    {
      chat_id: userId,
      message_id: messageId,
      parse_mode: 'Markdown',
      reply_markup: { inline_keyboard: [[{ text: '« Back', callback_data: 'deposit_upi' }]] }
    }
  );
}

// ─── Show QR & Payment Details ────────────────────────────────────────────────
async function showQrAndPaymentDetails(userId, amount, upiApp) {
  const state = getState(userId);
  const refId = utils.generateRefId(userId);
  state.pendingRefId = refId;
  state.pendingAmount = amount;

  const appNames = { gpay: 'GPay', fampay: 'FamPay', any: 'Any UPI' };
  const appName = appNames[upiApp] || 'UPI';

  const qrFileId = await db.getSetting(`qr_${upiApp}`);
  const qrInfo = await db.getSetting(`qr_${upiApp}_info`);
  const upiTextId = await db.getSetting('upi_text_id');
  const upiId = await db.getSetting('upi_id');
  const displayId = upiTextId || upiId || null;

  let text =
    `📱 *${appName} Payment*\n\n` +
    `💰 *Amount to Pay: Rs ${amount}*\n` +
    `📝 *Reference ID:* \`${refId}\`\n\n`;

  if (displayId) {
    text += `🆔 *Pay to UPI ID:* \`${displayId}\`\n\n`;
  }
  if (qrInfo) {
    text += `ℹ️ ${qrInfo}\n\n`;
  }

  text +=
    `*Instructions:*\n` +
    `1️⃣ Pay exactly *Rs ${amount}*\n` +
    `2️⃣ Use Reference ID as payment note/remark\n` +
    `3️⃣ Take a screenshot after payment\n` +
    `4️⃣ Click "I Have Paid" and send the screenshot\n\n` +
    `⏱️ Approval within 15–30 minutes.`;

  const keyboard = {
    inline_keyboard: [
      [{ text: '✅ I Have Paid — Send Screenshot', callback_data: 'i_have_paid' }],
      [{ text: '❌ Cancel', callback_data: 'cancel_deposit' }]
    ]
  };

  // ✅ SAME BOT — QR file_id seedha kaam karega, koi cross-bot relay nahi chahiye
  if (qrFileId && qrFileId !== '') {
    await bot.sendPhoto(userId, qrFileId, {
      caption: text,
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });
  } else {
    await bot.sendMessage(userId, text, {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });
  }
}

// ─── Ask Payment Screenshot ───────────────────────────────────────────────────
async function askPaymentScreenshot(userId, messageId) {
  const state = getState(userId);
  state.waitingScreenshot = true;

  try {
    await bot.editMessageText(
      `📸 *Send Payment Screenshot*\n\n` +
      `Please send the screenshot of your payment confirmation now.\n\n` +
      `📝 Reference ID: \`${state.pendingRefId || 'N/A'}\``,
      {
        chat_id: userId,
        message_id: messageId,
        parse_mode: 'Markdown',
        reply_markup: { inline_keyboard: [[{ text: '❌ Cancel', callback_data: 'cancel_deposit' }]] }
      }
    );
  } catch {
    await bot.sendMessage(userId,
      `📸 *Send Payment Screenshot*\n\nPlease send your payment screenshot now.`,
      { parse_mode: 'Markdown' }
    );
  }
}

// ─── BNB Deposit ──────────────────────────────────────────────────────────────
async function showBnbDeposit(userId, messageId) {
  const bnbAddress = await db.getSetting('bnb_address') || 'Address not configured';
  const refId = utils.generateRefId(userId);
  const qrFileId = await db.getSetting('qr_bnb');
  const qrInfo = await db.getSetting('qr_bnb_info');

  const text =
    `🟡 *USDT Deposit (BNB Smart Chain / BEP20)*\n\n` +
    `Send *USDT (BEP20)* to this address:\n` +
    `\`${bnbAddress}\`\n\n` +
    `📝 *Your Ref ID:* \`${refId}\`\n\n` +
    (qrInfo ? `ℹ️ ${qrInfo}\n\n` : '') +
    `⚠️ *Important:*\n` +
    `🔸 Send only USDT on BEP20 network\n` +
    `🔸 Include Ref ID in transaction memo if possible\n` +
    `🔸 Balance added after blockchain confirmation\n` +
    `🔸 Contact support with Ref ID after sending`;

  const keyboard = {
    inline_keyboard: [
      [{ text: '📞 Contact Support', callback_data: 'support' }],
      [{ text: '« Back', callback_data: 'deposit' }]
    ]
  };

  if (qrFileId && qrFileId !== '') {
    await bot.editMessageText('⏳ Loading...', { chat_id: userId, message_id: messageId });
    await bot.sendPhoto(userId, qrFileId, {
      caption: text,
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });
  } else {
    await bot.editMessageText(text, {
      chat_id: userId,
      message_id: messageId,
      parse_mode: 'Markdown',
      reply_markup: keyboard
    });
  }
}

// ─── Referral ─────────────────────────────────────────────────────────────────
async function showReferral(userId, messageId) {
  const refEnabled = await db.getSetting('referral_enabled') === '1';

  if (!refEnabled) {
    await bot.editMessageText(
      `🎁 *Referral Program*\n\nCurrently disabled. Check back soon!`,
      { chat_id: userId, message_id: messageId, parse_mode: 'Markdown', reply_markup: utils.getBackKeyboard() }
    );
    return;
  }

  const u = await db.getUser(userId);
  const refReward = await db.getSetting('referral_reward_inr') || '10';
  const earnedUsdt = await utils.inrToUsdt(u.referral_earned);
  const me = await bot.getMe();
  const refLink = `https://t.me/${me.username}?start=ref_${userId}`;

  const text =
    `🎁 *Refer & Earn*\n\n` +
    `Earn *Rs ${refReward}* for every friend who joins using your link!\n\n` +
    `*📊 Your Stats:*\n` +
    `👥 Referrals: ${u.referral_count}\n` +
    `💰 Total Earned: Rs ${u.referral_earned.toFixed(0)} ($${earnedUsdt.toFixed(2)})\n\n` +
    `*🔗 Your Referral Link:*\n` +
    `\`${refLink}\`\n\n` +
    `Share this link and earn when they join! 🚀`;

  await bot.editMessageText(text, {
    chat_id: userId,
    message_id: messageId,
    parse_mode: 'Markdown',
    reply_markup: utils.getBackKeyboard()
  });
}

// ─── Support ──────────────────────────────────────────────────────────────────
async function showSupport(userId, messageId) {
  const supportLink = await db.getSetting('support_link') || config.SUPPORT_LINK;

  const text =
    `📞 *Support*\n\n` +
    `Need help? Our support team is here for you. 🤝\n\n` +
    `*Before contacting support:*\n` +
    `🔸 Check your Reference ID for deposits\n` +
    `🔸 Wait 30 minutes for deposit approval\n` +
    `🔸 Check the FAQ in our group\n\n` +
    `*Contact Support:* 👇`;

  await bot.editMessageText(text, {
    chat_id: userId,
    message_id: messageId,
    parse_mode: 'Markdown',
    reply_markup: {
      inline_keyboard: [
        [{ text: '💬 Contact Support', url: supportLink }],
        [{ text: '🏠 Back to Menu', callback_data: 'main_menu' }]
      ]
    }
  });
}

// ════════════════════════════════════════════════════════════════════════════
// ─── ADMIN PANEL FUNCTIONS ────────────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════════════════

async function showAdminMenu(userId, messageId) {
  const stats = await db.getStats();
  const text =
    `👑 *Admin Control Panel*\n\n` +
    `👥 Users: ${stats.totalUsers} | 📥 Pending: ${stats.pendingDeposits}\n\n` +
    `Select an option: 👇`;

  const keyboard = {
    inline_keyboard: [
      [
        { text: `📥 Deposits (${stats.pendingDeposits})`, callback_data: 'adm_deposits' },
        { text: '📦 Products', callback_data: 'adm_products' }
      ],
      [
        { text: '💳 Payment Methods', callback_data: 'adm_payments' },
        { text: '💱 Rate Settings', callback_data: 'adm_rate' }
      ],
      [
        { text: '🎁 Referral', callback_data: 'adm_referral' },
        { text: '👥 Users', callback_data: 'adm_users' }
      ],
      [
        { text: '🔗 Links', callback_data: 'adm_links' },
        { text: '📊 Stats', callback_data: 'adm_stats' }
      ],
      [
        { text: '📢 Broadcast', callback_data: 'adm_broadcast' },
        { text: '🔑 Password', callback_data: 'adm_password' }
      ]
    ]
  };

  if (messageId) {
    try {
      await bot.editMessageText(text, { chat_id: userId, message_id: messageId, parse_mode: 'Markdown', reply_markup: keyboard });
      return;
    } catch {}
  }
  await bot.sendMessage(userId, text, { parse_mode: 'Markdown', reply_markup: keyboard });
}

// ─── Admin Callback Router ────────────────────────────────────────────────────
async function handleAdminCallback(userId, data, messageId) {
  try {
    if (data === 'adm_menu') {
      await showAdminMenu(userId, messageId);
    } else if (data === 'adm_deposits') {
      await showPendingDeposits(userId, messageId);
    } else if (data === 'adm_products') {
      await showProductsMenu(userId, messageId);
    } else if (data === 'adm_sold_products') {
      await showSoldProducts(userId, messageId);
    } else if (data === 'adm_payments') {
      await showPaymentMethods(userId, messageId);
    } else if (data === 'adm_rate') {
      await showRateSettings(userId, messageId);
    } else if (data === 'adm_referral') {
      await showReferralSettings(userId, messageId);
    } else if (data === 'adm_users') {
      await showUsersMenu(userId, messageId);
    } else if (data === 'adm_broadcast') {
      await startBroadcast(userId, messageId);
    } else if (data === 'adm_stats') {
      await showStats(userId, messageId);
    } else if (data === 'adm_password') {
      await showPasswordSettings(userId, messageId);
    } else if (data === 'adm_links') {
      await showLinksSettings(userId, messageId);
    } else if (data === 'adm_change_group') {
      getState(userId).waitingGroupLink = true;
      await bot.sendMessage(userId, '✍️ Enter new Group link:');
    } else if (data === 'adm_change_channel') {
      getState(userId).waitingChannelLink = true;
      await bot.sendMessage(userId, '✍️ Enter new Channel link:');
    } else if (data === 'adm_change_support') {
      getState(userId).waitingSupportLink = true;
      await bot.sendMessage(userId, '✍️ Enter new Support link:');
    } else if (data.startsWith('adm_approve_')) {
      const refId = data.replace('adm_approve_', '');
      await approveDeposit(userId, refId);
    } else if (data.startsWith('adm_reject_')) {
      const refId = data.replace('adm_reject_', '');
      await rejectDeposit(userId, refId);
    } else if (data.startsWith('adm_view_ss_')) {
      const refId = data.replace('adm_view_ss_', '');
      await viewDepositScreenshot(userId, refId);
    } else if (data.startsWith('adm_msg_')) {
      const targetId = parseInt(data.replace('adm_msg_', ''));
      const state = getState(userId);
      state.sendMsgTo = targetId;
      state.waitingSendMsg = true;
      await bot.sendMessage(userId, `✍️ Type your message for user \`${targetId}\`:`, { parse_mode: 'Markdown' });
    } else if (data === 'adm_add_product') {
      await startAddProduct(userId);
    } else if (data.startsWith('adm_edit_product_')) {
      const pid = parseInt(data.replace('adm_edit_product_', ''));
      await showEditProduct(userId, pid);
    } else if (data.startsWith('adm_del_product_')) {
      const pid = parseInt(data.replace('adm_del_product_', ''));
      await confirmDeleteProduct(userId, pid);
    } else if (data.startsWith('adm_confirm_del_')) {
      const pid = parseInt(data.replace('adm_confirm_del_', ''));
      await deleteProduct(userId, pid);
    } else if (data.startsWith('adm_add_more_')) {
      const pid = parseInt(data.replace('adm_add_more_', ''));
      const state = getState(userId);
      state.addingStockToProduct = pid;
      state.waitingAddStock = true;
      await bot.sendMessage(userId, `✍️ Enter number of stock to add for product ID ${pid}:`);
    } else if (data.startsWith('adm_edit_field_')) {
      const raw = data.replace('adm_edit_field_', '');
      const idx = raw.indexOf('_');
      const pid = parseInt(raw.substring(0, idx));
      const field = raw.substring(idx + 1);
      const state = getState(userId);
      state.editingProductId = pid;
      state.editingField = field;
      state.waitingProductEdit = true;
      const labels = { name: 'Product Name', price_inr: 'Price (Rs)', stock: 'Stock Count', description: 'Description', content: 'Product Content' };
      await bot.sendMessage(userId, `✍️ Enter new ${labels[field] || field}:`);
    } else if (data === 'adm_toggle_upi') {
      await togglePayment(userId, messageId, 'upi_enabled');
    } else if (data === 'adm_toggle_bnb') {
      await togglePayment(userId, messageId, 'bnb_enabled');
    } else if (data === 'adm_toggle_fampay') {
      await togglePayment(userId, messageId, 'fampay_enabled');
    } else if (data === 'adm_toggle_referral') {
      const current = await db.getSetting('referral_enabled');
      await db.setSetting('referral_enabled', current === '1' ? '0' : '1');
      await showReferralSettings(userId, messageId);
    } else if (data === 'adm_upi_settings') {
      await showUpiSettings(userId, messageId);
    } else if (data === 'adm_change_upi_id') {
      getState(userId).waitingUpiId = true;
      await bot.sendMessage(userId, '✍️ Enter new UPI ID (e.g. name@upi):');
    } else if (data === 'adm_change_upi_text_id') {
      getState(userId).waitingUpiTextId = true;
      await bot.sendMessage(userId, '✍️ Enter Display UPI Text ID to show users (e.g. yourname@bank):');
    } else if (data === 'adm_change_qr') {
      await showQrChangeMenu(userId, messageId);
    } else if (data.startsWith('adm_qr_method_')) {
      const method = data.replace('adm_qr_method_', '');
      const state = getState(userId);
      state.qrUploadMethod = method;
      state.waitingQrUpload = true;
      const names = { gpay: 'GPay', fampay: 'FamPay', any: 'Any UPI', bnb: 'BNB' };
      await bot.sendMessage(userId,
        `📸 Send the QR code image for *${names[method] || method}*.\n\n` +
        `You can also send your UPI ID and your account name/ID along with it (as the photo caption) if available — this will stay saved until you delete or change it again. ✅`,
        { parse_mode: 'Markdown' }
      );
    } else if (data === 'adm_set_rate') {
      getState(userId).waitingRate = true;
      await bot.sendMessage(userId, '✍️ Enter new USDT to INR rate (e.g. 90):');
    } else if (data === 'adm_set_ref_reward') {
      getState(userId).waitingRefReward = true;
      await bot.sendMessage(userId, '✍️ Enter referral reward amount (Rs):');
    } else if (data.startsWith('adm_user_')) {
      const uid = parseInt(data.replace('adm_user_', ''));
      await showUserDetail(userId, uid);
    } else if (data.startsWith('adm_ban_')) {
      const uid = parseInt(data.replace('adm_ban_', ''));
      await toggleBanUser(userId, uid);
    } else if (data.startsWith('adm_restrict_')) {
      const uid = parseInt(data.replace('adm_restrict_', ''));
      await toggleRestrictUser(userId, uid);
    } else if (data === 'adm_change_password') {
      getState(userId).waitingNewPassword = true;
      await bot.sendMessage(userId, '✍️ Enter new admin password:');
    } else if (data === 'adm_logout') {
      authenticatedAdmins.delete(userId);
      await db.setSetting(`admin_auth_${userId}`, '0');
      await bot.sendMessage(userId, '🔒 Logged out of Admin Panel. Send /admin to log in again.');
    } else if (data === 'adm_set_bnb_addr') {
      getState(userId).waitingBnbAddress = true;
      await bot.sendMessage(userId, '✍️ Enter your BNB Wallet Address:');
    } else if (data.startsWith('adm_deliver_')) {
      const purchaseId = parseInt(data.replace('adm_deliver_', ''));
      await deliverPurchase(userId, purchaseId);
    } else if (data.startsWith('adm_refund_')) {
      const purchaseId = parseInt(data.replace('adm_refund_', ''));
      await refundPurchase(userId, purchaseId);
    } else if (data === 'noop') {
      // separator — do nothing
    }
  } catch (err) {
    console.error('Admin callback error:', err.message);
  }
}

// ─── Pending Deposits ─────────────────────────────────────────────────────────
async function showPendingDeposits(userId, messageId) {
  const deposits = await db.getPendingDeposits();

  if (!deposits.length) {
    try {
      await bot.editMessageText(
        `📥 *Pending Deposits*\n\n✅ No pending deposits!`,
        { chat_id: userId, message_id: messageId, parse_mode: 'Markdown', reply_markup: backBtn() }
      );
    } catch {}
    return;
  }

  let text = `📥 *Pending Deposits (${deposits.length})*\n\n`;
  const keyboard = [];

  for (const dep of deposits) {
    text +=
      `👤 *${dep.full_name}*\n` +
      `💰 Rs ${dep.amount_inr.toFixed(0)} | 📱 ${dep.method || 'UPI'}\n` +
      `🆔 \`${dep.ref_id}\`\n\n`;

    keyboard.push([
      { text: `✅ Approve Rs ${dep.amount_inr.toFixed(0)}`, callback_data: `adm_approve_${dep.ref_id}` },
      { text: '❌ Reject', callback_data: `adm_reject_${dep.ref_id}` }
    ]);
    keyboard.push([
      { text: `📸 View Screenshot`, callback_data: `adm_view_ss_${dep.ref_id}` },
      { text: '💬 Message', callback_data: `adm_msg_${dep.user_id}` }
    ]);
  }

  keyboard.push([{ text: '« Back', callback_data: 'adm_menu' }]);

  try {
    await bot.editMessageText(text, {
      chat_id: userId,
      message_id: messageId,
      parse_mode: 'Markdown',
      reply_markup: { inline_keyboard: keyboard }
    });
  } catch {}
}

// ─── View Screenshot ──────────────────────────────────────────────────────────
async function viewDepositScreenshot(userId, refId) {
  const database = await db.getDB();
  const deposit = await database.get(
    `SELECT d.*, u.full_name, u.username FROM deposits d JOIN users u ON d.user_id = u.user_id WHERE d.ref_id = ?`, refId
  );

  if (!deposit) {
    await bot.sendMessage(userId, '❌ Deposit not found.');
    return;
  }

  if (!deposit.screenshot_file_id) {
    await bot.sendMessage(userId, `⚠️ No screenshot for this deposit.\nRef: \`${refId}\``, { parse_mode: 'Markdown' });
    return;
  }

  const caption =
    `📸 *Payment Screenshot*\n\n` +
    `👤 *User:* ${deposit.full_name} (@${deposit.username || 'N/A'})\n` +
    `💰 *Amount:* Rs ${deposit.amount_inr.toFixed(0)}\n` +
    `📝 *Ref ID:* \`${deposit.ref_id}\`\n` +
    `📱 *Method:* ${deposit.method || 'UPI'}\n` +
    `🕐 *Time:* ${utils.formatDateTime(deposit.created_at)}\n` +
    `📊 *Status:* ${deposit.status}`;

  // ✅ SAME BOT — file_id seedha valid hai, koi relay nahi chahiye
  await bot.sendPhoto(userId, deposit.screenshot_file_id, {
    caption: caption,
    parse_mode: 'Markdown',
    reply_markup: {
      inline_keyboard: [
        [
          { text: `✅ Approve Rs ${deposit.amount_inr.toFixed(0)}`, callback_data: `adm_approve_${refId}` },
          { text: '❌ Reject', callback_data: `adm_reject_${refId}` }
        ],
        [{ text: '« Back to Deposits', callback_data: 'adm_deposits' }]
      ]
    }
  });
}

// ─── Approve Deposit ──────────────────────────────────────────────────────────
async function approveDeposit(userId, refId) {
  const database = await db.getDB();
  const deposit = await database.get('SELECT * FROM deposits WHERE ref_id = ?', refId);

  if (!deposit || deposit.status !== 'pending') {
    await bot.sendMessage(userId, '⚠️ Deposit not found or already processed.');
    return;
  }

  await database.run(
    `UPDATE deposits SET status = 'approved', approved_at = CURRENT_TIMESTAMP WHERE ref_id = ?`, refId
  );
  await db.updateUserBalance(deposit.user_id, deposit.amount_inr);

  try {
    await bot.sendMessage(deposit.user_id,
      `✅ *Payment Approved!* 🎉\n\n` +
      `Rs ${deposit.amount_inr.toFixed(0)} has been added to your wallet.\n` +
      `📝 Ref: \`${refId}\`\n\nThank you for your deposit!`,
      { parse_mode: 'Markdown' }
    );
  } catch (err) {
    console.error('notifyUser error:', err.message);
  }

  await bot.sendMessage(userId,
    `✅ *Approved!*\n\nRs ${deposit.amount_inr.toFixed(0)} added to user \`${deposit.user_id}\` wallet.`,
    { parse_mode: 'Markdown', reply_markup: backBtn('« Back to Deposits', 'adm_deposits') }
  );
}

// ─── Reject Deposit ───────────────────────────────────────────────────────────
async function rejectDeposit(userId, refId) {
  const database = await db.getDB();
  const deposit = await database.get('SELECT * FROM deposits WHERE ref_id = ?', refId);

  if (!deposit) {
    await bot.sendMessage(userId, '⚠️ Deposit not found.');
    return;
  }

  await database.run(`UPDATE deposits SET status = 'rejected' WHERE ref_id = ?`, refId);

  try {
    await bot.sendMessage(deposit.user_id,
      `❌ *Payment Rejected*\n\n` +
      `Your deposit of Rs ${deposit.amount_inr.toFixed(0)} was not approved.\n` +
      `📝 Ref: \`${refId}\`\n\nContact support if you think this is an error.`,
      { parse_mode: 'Markdown' }
    );
  } catch (err) {
    console.error('notifyUser error:', err.message);
  }

  await bot.sendMessage(userId,
    `❌ *Rejected!*\n\nDeposit \`${refId.substring(0, 25)}\` rejected.`,
    { parse_mode: 'Markdown', reply_markup: backBtn('« Back to Deposits', 'adm_deposits') }
  );
}

// ─── Products Menu ────────────────────────────────────────────────────────────
async function showProductsMenu(userId, messageId) {
  const products = await db.getAllProducts();

  let text = `📦 *Products Management*\n\n`;
  const keyboard = [
    [
      { text: '➕ Add New Product', callback_data: 'adm_add_product' },
      { text: '📊 Sold Report', callback_data: 'adm_sold_products' }
    ]
  ];

  if (!products.length) {
    text += 'No products yet. Add your first product! 🆕';
  } else {
    for (const p of products) {
      const status = p.stock > 0 ? '🟢' : '🔴';
      text += `${status} *${p.name}*\n   💰 Rs ${p.price_inr.toFixed(0)} | 📦 Stock: ${p.stock} | Sold: ${p.total_sold}\n\n`;
      keyboard.push([
        { text: `✏️ Edit`, callback_data: `adm_edit_product_${p.id}` },
        { text: `➕ Add Stock`, callback_data: `adm_add_more_${p.id}` },
        { text: `🗑️ Delete`, callback_data: `adm_del_product_${p.id}` }
      ]);
    }
  }

  keyboard.push([{ text: '« Back', callback_data: 'adm_menu' }]);

  try {
    await bot.editMessageText(text, {
      chat_id: userId, message_id: messageId, parse_mode: 'Markdown',
      reply_markup: { inline_keyboard: keyboard }
    });
  } catch {}
}

// ─── Sold Products ────────────────────────────────────────────────────────────
async function showSoldProducts(userId, messageId) {
  const sold = await db.getSoldProducts();

  let text = `📊 *Sold Products Report*\n\n`;
  let totalRevenue = 0;

  if (!sold.length) {
    text += 'No products sold yet.';
  } else {
    for (const p of sold) {
      text += `📦 *${p.name}*\n   🛒 Sold: ${p.total_sold} | 💰 Revenue: Rs ${(p.total_revenue || 0).toFixed(0)}\n\n`;
      totalRevenue += p.total_revenue || 0;
    }
    text += `*💰 Total Revenue: Rs ${totalRevenue.toFixed(0)}*`;
  }

  try {
    await bot.editMessageText(text, {
      chat_id: userId, message_id: messageId, parse_mode: 'Markdown',
      reply_markup: backBtn('« Back to Products', 'adm_products')
    });
  } catch {}
}

// ─── Add Product ──────────────────────────────────────────────────────────────
async function startAddProduct(userId) {
  const state = getState(userId);
  state.addingProduct = { step: 'name', data: {} };
  await bot.sendMessage(userId, `➕ *Add New Product*\n\n*Step 1/5:* Enter product name: ✍️`, { parse_mode: 'Markdown' });
}

// ─── Edit Product ─────────────────────────────────────────────────────────────
async function showEditProduct(userId, pid) {
  const database = await db.getDB();
  const p = await database.get('SELECT * FROM products WHERE id = ?', pid);

  if (!p) { await bot.sendMessage(userId, '❌ Product not found.'); return; }

  const text =
    `✏️ *Edit Product*\n\n` +
    `*Name:* ${p.name}\n*Price:* Rs ${p.price_inr.toFixed(0)}\n` +
    `*Stock:* ${p.stock}\n*Total Sold:* ${p.total_sold}\n` +
    `*Description:* ${p.description || 'N/A'}\n\nSelect field to edit: 👇`;

  await bot.sendMessage(userId, text, {
    parse_mode: 'Markdown',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '📝 Name', callback_data: `adm_edit_field_${pid}_name` },
          { text: '💰 Price', callback_data: `adm_edit_field_${pid}_price_inr` }
        ],
        [
          { text: '📦 Stock', callback_data: `adm_edit_field_${pid}_stock` },
          { text: '📄 Description', callback_data: `adm_edit_field_${pid}_description` }
        ],
        [{ text: '🔑 Content', callback_data: `adm_edit_field_${pid}_content` }],
        [
          { text: '➕ Add Stock', callback_data: `adm_add_more_${pid}` },
          { text: '« Back', callback_data: 'adm_products' }
        ]
      ]
    }
  });
}

// ─── Confirm Delete ───────────────────────────────────────────────────────────
async function confirmDeleteProduct(userId, pid) {
  const database = await db.getDB();
  const p = await database.get('SELECT * FROM products WHERE id = ?', pid);
  if (!p) { await bot.sendMessage(userId, '❌ Product not found.'); return; }

  await bot.sendMessage(userId,
    `⚠️ *Confirm Delete?*\n\nProduct: *${p.name}*\nStock remaining: ${p.stock}\n\nThis will deactivate the product.`,
    {
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '🗑️ Yes, Delete', callback_data: `adm_confirm_del_${pid}` },
            { text: '« Cancel', callback_data: `adm_edit_product_${pid}` }
          ]
        ]
      }
    }
  );
}

// ─── Delete Product ───────────────────────────────────────────────────────────
async function deleteProduct(userId, pid) {
  const database = await db.getDB();
  await database.run('UPDATE products SET is_active = 0 WHERE id = ?', pid);
  await bot.sendMessage(userId, `✅ Product deactivated successfully.`, { reply_markup: backBtn('« Back to Products', 'adm_products') });
}

// ─── Payment Methods ──────────────────────────────────────────────────────────
async function showPaymentMethods(userId, messageId) {
  const upi = await db.getSetting('upi_enabled') === '1' ? 'ON ✅' : 'OFF ❌';
  const bnb = await db.getSetting('bnb_enabled') === '1' ? 'ON ✅' : 'OFF ❌';
  const fampay = await db.getSetting('fampay_enabled') === '1' ? 'ON ✅' : 'OFF ❌';

  const text =
    `💳 *Payment Methods*\n\n` +
    `📱 UPI: ${upi}\n` +
    `💳 FamPay: ${fampay}\n` +
    `🟡 BNB Chain: ${bnb}\n\n` +
    `Tap to toggle or manage: 👇`;

  const keyboard = {
    inline_keyboard: [
      [
        { text: `📱 UPI ${upi}`, callback_data: 'adm_toggle_upi' },
        { text: `💳 FamPay ${fampay}`, callback_data: 'adm_toggle_fampay' }
      ],
      [{ text: `🟡 BNB ${bnb}`, callback_data: 'adm_toggle_bnb' }],
      [{ text: '⚙️ UPI Settings', callback_data: 'adm_upi_settings' }],
      [{ text: '📸 Change QR Codes', callback_data: 'adm_change_qr' }],
      [{ text: '🏦 Set BNB Address', callback_data: 'adm_set_bnb_addr' }],
      [{ text: '« Back', callback_data: 'adm_menu' }]
    ]
  };

  try {
    await bot.editMessageText(text, { chat_id: userId, message_id: messageId, parse_mode: 'Markdown', reply_markup: keyboard });
  } catch {}
}

async function togglePayment(userId, messageId, key) {
  const current = await db.getSetting(key);
  await db.setSetting(key, current === '1' ? '0' : '1');
  await showPaymentMethods(userId, messageId);
}

// ─── UPI Settings ─────────────────────────────────────────────────────────────
async function showUpiSettings(userId, messageId) {
  const upiId = await db.getSetting('upi_id') || 'Not set';
  const upiTextId = await db.getSetting('upi_text_id') || 'Not set';

  const text =
    `⚙️ *UPI Settings*\n\n` +
    `*Primary UPI ID:* \`${upiId}\`\n` +
    `*Display Text ID:* \`${upiTextId}\`\n\n` +
    `🔸 Primary UPI ID — internal reference\n` +
    `🔸 Display Text ID — shown to users on payment screen`;

  const keyboard = {
    inline_keyboard: [
      [{ text: '✏️ Change UPI ID', callback_data: 'adm_change_upi_id' }],
      [{ text: '🔤 Change Display Text ID', callback_data: 'adm_change_upi_text_id' }],
      [{ text: '« Back', callback_data: 'adm_payments' }]
    ]
  };

  try {
    await bot.editMessageText(text, { chat_id: userId, message_id: messageId, parse_mode: 'Markdown', reply_markup: keyboard });
  } catch {}
}

// ─── QR Change Menu ───────────────────────────────────────────────────────────
async function showQrChangeMenu(userId, messageId) {
  const keyboard = {
    inline_keyboard: [
      [
        { text: '📱 GPay QR', callback_data: 'adm_qr_method_gpay' },
        { text: '💳 FamPay QR', callback_data: 'adm_qr_method_fampay' }
      ],
      [
        { text: '📲 Any UPI QR', callback_data: 'adm_qr_method_any' },
        { text: '🟡 BNB QR', callback_data: 'adm_qr_method_bnb' }
      ],
      [{ text: '« Back', callback_data: 'adm_payments' }]
    ]
  };

  try {
    await bot.editMessageText(
      `📸 *Change QR Code*\n\nSelect which QR code to update: 👇`,
      { chat_id: userId, message_id: messageId, parse_mode: 'Markdown', reply_markup: keyboard }
    );
  } catch {}
}

// ─── Rate Settings ────────────────────────────────────────────────────────────
async function showRateSettings(userId, messageId) {
  const rate = await db.getSetting('usdt_to_inr_rate') || '90';
  try {
    await bot.editMessageText(
      `💱 *Rate Settings*\n\n*Current Rate:* 1 USDT = Rs ${rate}`,
      {
        chat_id: userId,
        message_id: messageId,
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '✏️ Change Rate', callback_data: 'adm_set_rate' }],
            [{ text: '« Back', callback_data: 'adm_menu' }]
          ]
        }
      }
    );
  } catch {}
}

// ─── Referral Settings ────────────────────────────────────────────────────────
async function showReferralSettings(userId, messageId) {
  const enabled = await db.getSetting('referral_enabled') === '1';
  const reward = await db.getSetting('referral_reward_inr') || '10';

  try {
    await bot.editMessageText(
      `🎁 *Referral Settings*\n\n` +
      `Status: ${enabled ? '✅ Active' : '❌ Disabled'}\n` +
      `Reward per referral: *Rs ${reward}*`,
      {
        chat_id: userId,
        message_id: messageId,
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: enabled ? '❌ Disable' : '✅ Enable', callback_data: 'adm_toggle_referral' }],
            [{ text: '✏️ Change Reward Amount', callback_data: 'adm_set_ref_reward' }],
            [{ text: '« Back', callback_data: 'adm_menu' }]
          ]
        }
      }
    );
  } catch {}
}

// ─── Links Settings ───────────────────────────────────────────────────────────
async function showLinksSettings(userId, messageId) {
  const group = await db.getSetting('group_link') || 'Not set';
  const channel = await db.getSetting('channel_link') || 'Not set';
  const support = await db.getSetting('support_link') || 'Not set';

  try {
    await bot.editMessageText(
      `🔗 *Links Settings*\n\n` +
      `👥 Group: ${group}\n` +
      `📢 Channel: ${channel}\n` +
      `📞 Support: ${support}`,
      {
        chat_id: userId,
        message_id: messageId,
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '👥 Change Group Link', callback_data: 'adm_change_group' }],
            [{ text: '📢 Change Channel Link', callback_data: 'adm_change_channel' }],
            [{ text: '📞 Change Support Link', callback_data: 'adm_change_support' }],
            [{ text: '« Back', callback_data: 'adm_menu' }]
          ]
        }
      }
    );
  } catch {}
}

// ─── Users Menu ───────────────────────────────────────────────────────────────
async function showUsersMenu(userId, messageId) {
  const users = await db.getAllUsers();

  let text = `👥 *Users (${users.length} total)*\n\n`;
  const keyboard = [];

  const recent = users.slice(0, 10);
  for (const u of recent) {
    const status = u.is_banned ? '🚫' : '✅';
    text += `${status} ${u.full_name} | Rs ${u.balance_inr.toFixed(0)}\n`;
    keyboard.push([{ text: `${status} ${u.full_name}`, callback_data: `adm_user_${u.user_id}` }]);
  }

  if (users.length > 10) {
    text += `\n_Showing 10 of ${users.length} users_`;
  }

  keyboard.push([{ text: '« Back', callback_data: 'adm_menu' }]);

  try {
    await bot.editMessageText(text, {
      chat_id: userId, message_id: messageId, parse_mode: 'Markdown',
      reply_markup: { inline_keyboard: keyboard }
    });
  } catch {}
}

// ─── User Detail ──────────────────────────────────────────────────────────────
async function showUserDetail(userId, targetUid) {
  const u = await db.getUser(targetUid);
  if (!u) { await bot.sendMessage(userId, '❌ User not found.'); return; }

  const text =
    `👤 *User Detail*\n\n` +
    `Name: ${u.full_name}\n` +
    `Username: @${u.username || 'N/A'}\n` +
    `ID: \`${u.user_id}\`\n` +
    `Joined: ${utils.formatDateTime(u.joined_at)}\n\n` +
    `💰 Balance: Rs ${u.balance_inr.toFixed(0)}\n` +
    `📥 Deposited: Rs ${u.total_deposited.toFixed(0)}\n` +
    `💸 Spent: Rs ${u.total_spent.toFixed(0)}\n` +
    `🛍️ Purchases: ${u.total_purchases}\n` +
    `👥 Referrals: ${u.referral_count}\n\n` +
    `Status: ${u.is_banned ? '🚫 Banned' : u.is_restricted ? '⚠️ Restricted' : '✅ Active'}`;

  await bot.sendMessage(userId, text, {
    parse_mode: 'Markdown',
    reply_markup: {
      inline_keyboard: [
        [
          { text: u.is_banned ? '✅ Unban' : '🚫 Ban', callback_data: `adm_ban_${targetUid}` },
          { text: u.is_restricted ? '✅ Unrestrict' : '⚠️ Restrict', callback_data: `adm_restrict_${targetUid}` }
        ],
        [{ text: '💬 Send Message', callback_data: `adm_msg_${targetUid}` }],
        [{ text: '« Back to Users', callback_data: 'adm_users' }]
      ]
    }
  });
}

// ─── Ban/Restrict ─────────────────────────────────────────────────────────────
async function toggleBanUser(userId, targetUid) {
  const database = await db.getDB();
  const u = await db.getUser(targetUid);
  if (!u) return;
  const newBan = u.is_banned ? 0 : 1;
  await database.run('UPDATE users SET is_banned = ? WHERE user_id = ?', newBan, targetUid);
  await bot.sendMessage(userId,
    `${newBan ? '🚫 User banned' : '✅ User unbanned'}: \`${targetUid}\``,
    { parse_mode: 'Markdown', reply_markup: backBtn('« Back to Users', 'adm_users') }
  );
}

async function toggleRestrictUser(userId, targetUid) {
  const database = await db.getDB();
  const u = await db.getUser(targetUid);
  if (!u) return;
  const newRestrict = u.is_restricted ? 0 : 1;
  await database.run('UPDATE users SET is_restricted = ? WHERE user_id = ?', newRestrict, targetUid);
  await bot.sendMessage(userId,
    `${newRestrict ? '⚠️ User restricted' : '✅ User unrestricted'}: \`${targetUid}\``,
    { parse_mode: 'Markdown', reply_markup: backBtn('« Back to Users', 'adm_users') }
  );
}

// ─── Stats ────────────────────────────────────────────────────────────────────
async function showStats(userId, messageId) {
  const stats = await db.getStats();

  const text =
    `📊 *Bot Statistics*\n\n` +
    `👥 Total Users: ${stats.totalUsers}\n` +
    `📥 Pending Deposits: ${stats.pendingDeposits}\n` +
    `💰 Total Deposited: Rs ${stats.totalDeposits.toFixed(0)}\n` +
    `💸 Total Revenue: Rs ${stats.totalRevenue.toFixed(0)}\n` +
    `🛍️ Total Sales: ${stats.totalSalesCount}\n` +
    `📦 Active Products: ${stats.totalProducts}`;

  try {
    await bot.editMessageText(text, { chat_id: userId, message_id: messageId, parse_mode: 'Markdown', reply_markup: backBtn() });
  } catch {}
}

// ─── Password Settings ────────────────────────────────────────────────────────
async function showPasswordSettings(userId, messageId) {
  try {
    await bot.editMessageText(
      `🔑 *Password & Session*\n\nManage your admin panel access:`,
      {
        chat_id: userId,
        message_id: messageId,
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '✏️ Change Password', callback_data: 'adm_change_password' }],
            [{ text: '🔒 Logout This Session', callback_data: 'adm_logout' }],
            [{ text: '« Back', callback_data: 'adm_menu' }]
          ]
        }
      }
    );
  } catch {}
}

// ─── Broadcast ────────────────────────────────────────────────────────────────
async function startBroadcast(userId, messageId) {
  getState(userId).waitingBroadcast = true;
  try {
    await bot.editMessageText(
      `📢 *Broadcast Message*\n\nType your message to send to ALL users: ✍️`,
      { chat_id: userId, message_id: messageId, parse_mode: 'Markdown', reply_markup: backBtn() }
    );
  } catch {}
}

// ─── Deliver Purchase ─────────────────────────────────────────────────────────
async function deliverPurchase(userId, purchaseId) {
  const database = await db.getDB();
  const purchase = await database.get(
    `SELECT pu.*, p.name as product_name, p.content
     FROM purchases pu
     JOIN products p ON pu.product_id = p.id
     WHERE pu.id = ?`, purchaseId
  );

  if (!purchase) { await bot.sendMessage(userId, '❌ Purchase not found.'); return; }

  const userMsg =
    `✅ *Your Order is Ready!* 🎉\n\n` +
    `📦 *${purchase.product_name}*\n\n` +
    `*Your Product:*\n\`\`\`\n${purchase.content}\n\`\`\`\n\n` +
    `🔒 Keep this secure. Do not share with anyone.\n` +
    `📞 Need help? Use Support in the menu.`;

  try {
    await bot.sendMessage(purchase.user_id, userMsg, { parse_mode: 'Markdown' });
  } catch (err) {
    console.error('Failed to deliver to user:', err.message);
  }

  await bot.sendMessage(userId,
    `✅ *Product Delivered!*\n\n📦 ${purchase.product_name}\n👤 User ID: \`${purchase.user_id}\`\n🆔 Purchase ID: \`${purchaseId}\``,
    { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [[{ text: '« Back to Menu', callback_data: 'adm_menu' }]] } }
  );
}

// ─── Refund Purchase ──────────────────────────────────────────────────────────
async function refundPurchase(userId, purchaseId) {
  const database = await db.getDB();
  const purchase = await database.get(
    `SELECT pu.*, p.name as product_name
     FROM purchases pu
     JOIN products p ON pu.product_id = p.id
     WHERE pu.id = ?`, purchaseId
  );

  if (!purchase) { await bot.sendMessage(userId, '❌ Purchase not found.'); return; }

  await database.run(
    `UPDATE users SET balance_inr = balance_inr + ?, total_spent = total_spent - ?, total_purchases = total_purchases - 1 WHERE user_id = ?`,
    purchase.amount_inr, purchase.amount_inr, purchase.user_id
  );

  await database.run(
    'UPDATE products SET stock = stock + 1, total_sold = total_sold - 1 WHERE id = ?', purchase.product_id
  );

  try {
    await bot.sendMessage(purchase.user_id,
      `❌ *Order Dismissed*\n\nYour order for *${purchase.product_name}* was dismissed by admin.\n✅ *Rs ${purchase.amount_inr.toFixed(0)}* has been refunded to your wallet.\n\nContact support if you have questions.`,
      { parse_mode: 'Markdown' }
    );
  } catch (err) {
    console.error('Failed to notify user of refund:', err.message);
  }

  await bot.sendMessage(userId,
    `✅ *Refunded!*\n\nRs ${purchase.amount_inr.toFixed(0)} refunded to user \`${purchase.user_id}\``,
    { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [[{ text: '« Back to Menu', callback_data: 'adm_menu' }]] } }
  );
}

// ════════════════════════════════════════════════════════════════════════════
// ─── Unified Message Handler (USER + ADMIN dono) ─────────────────────────────
// ════════════════════════════════════════════════════════════════════════════
bot.on('message', async (msg) => {
  if (!msg.from) return;
  const userId = msg.from.id;

  // ─── /admin aur /start already onText se handle ho rahe hain, skip ──────
  if (msg.text && msg.text.startsWith('/')) return;

  const isAdminAuthed = isOwner(userId) && (await isAdminAuthenticated(userId));
  const state = getState(userId);

  // ─── Admin Password Entry ─────────────────────────────────────────────────
  if (isOwner(userId) && state.waitingAdminPassword) {
    if (!msg.text) return;
    const text = msg.text.trim();
    if (text === config.ADMIN_PASSWORD) {
      await setAdminAuthenticated(userId);
      clearState(userId);
      await bot.sendMessage(userId, '✅ *Authenticated!* Welcome back, boss. 👑', { parse_mode: 'Markdown' });
      await showAdminMenu(userId);
    } else {
      await bot.sendMessage(userId, '❌ Wrong password. Try again: 🔐');
    }
    return;
  }

  // ─── Photo Handling ────────────────────────────────────────────────────────
  if (msg.photo) {
    // QR Upload (Admin) — ✅ SAME BOT hai, isliye file_id directly valid hai, koi relay nahi chahiye
    if (isAdminAuthed && state.waitingQrUpload) {
      const fileId = msg.photo[msg.photo.length - 1].file_id;
      const method = state.qrUploadMethod;
      const names = { gpay: 'GPay', fampay: 'FamPay', any: 'Any UPI', bnb: 'BNB' };
      const caption = msg.caption ? msg.caption.trim() : '';

      await db.setSetting(`qr_${method}`, fileId);
      if (caption) {
        await db.setSetting(`qr_${method}_info`, caption);
      }
      clearState(userId);
      await bot.sendMessage(userId,
        `✅ QR code updated for *${names[method] || method}*! 🎉\n\n` +
        `It will stay saved like this until you delete or change it again.` +
        (caption ? `\n📝 Info saved: ${caption}` : ''),
        { parse_mode: 'Markdown', reply_markup: backBtn('« Back to Payments', 'adm_payments') }
      );
      return;
    }

    // Screenshot Upload (User) — ✅ SAME BOT hai, file_id directly admin ko bhi dikhega
    if (state.waitingScreenshot) {
      await handlePhotoMessage(msg);
      return;
    }

    await bot.sendMessage(userId,
      `ℹ️ *Unexpected photo.*\n\nPlease use the menu to start the relevant action first.`,
      { parse_mode: 'Markdown' }
    );
    return;
  }

  if (!msg.text) return;
  const text = msg.text.trim();

  // ─── Admin Text Flows (sirf authenticated admin ke liye) ──────────────────
  if (isAdminAuthed) {
    const handled = await handleAdminTextInput(userId, state, text);
    if (handled) return;
  }

  // ─── User Text Flows ────────────────────────────────────────────────────────
  const banned = await utils.isUserBanned(userId);
  if (banned) return;

  const commandMap = {
    'menu': 'main_menu',
    'start': 'main_menu',
    'buy': 'buy_product',
    'profile': 'profile',
    'deposit': 'deposit',
    'refer': 'refer_earn',
    'support': 'support'
  };

  const lower = text.toLowerCase();
  if (commandMap.hasOwnProperty(lower)) {
    await handleTextCommand(userId, commandMap[lower]);
    return;
  }

  if (state.waitingDepositAmount) {
    const amount = parseFloat(text);
    const minDep = parseFloat(await db.getSetting('min_deposit_inr')) || 20;

    if (isNaN(amount) || amount < minDep) {
      await bot.sendMessage(userId, `⚠️ Please enter a valid amount of at least *Rs ${minDep}*`, { parse_mode: 'Markdown' });
      return;
    }

    state.waitingDepositAmount = false;
    await showQrAndPaymentDetails(userId, amount, state.upiApp);
    return;
  }

  const dbUser = await db.getUser(userId);
  if (!dbUser || !dbUser.terms_accepted) {
    if (isOwner(userId)) return; // owner ko terms ka spam mat karo
    return;
  }

  await bot.sendMessage(userId,
    `ℹ️ *This command is not recognized here.*\n\n` +
    `Please use the menu buttons to navigate.\n` +
    `Type /start to return to the main menu.`,
    { parse_mode: 'Markdown' }
  );
});

// ─── Handle Photo (Screenshot) ────────────────────────────────────────────────
async function handlePhotoMessage(msg) {
  const userId = msg.from.id;
  const state = getState(userId);

  const fileId = msg.photo[msg.photo.length - 1].file_id;
  const refId = state.pendingRefId;
  const amount = state.pendingAmount;
  const upiApp = state.upiApp || 'upi';

  if (!refId || !amount) {
    await bot.sendMessage(userId, `❌ Session expired. Please start the deposit process again.`);
    clearState(userId);
    return;
  }

  const database = await db.getDB();
  const dbUser = await db.getUser(userId);

  await database.run(
    `INSERT OR IGNORE INTO deposits (user_id, amount_inr, ref_id, method, screenshot_file_id, status) VALUES (?, ?, ?, ?, ?, 'pending')`,
    userId, amount, refId, upiApp, fileId
  );

  clearState(userId);

  await bot.sendMessage(userId,
    `✅ *Payment Screenshot Received!*\n\n` +
    `📝 Ref ID: \`${refId}\`\n` +
    `💰 Amount: Rs ${amount}\n\n` +
    `Your payment is under review.\n` +
    `Approval within *15–30 minutes*. ⏱️\n\n` +
    `Keep your Ref ID safe for any queries.`,
    { parse_mode: 'Markdown' }
  );

  // ✅ SAME BOT — fileId admin ko directly bhej sakte hain, koi cross-bot relay ki zaroorat nahi
  try {
    const adminCaption =
      `📥 *New Deposit Request*\n\n` +
      `👤 *User:* ${dbUser.full_name}\n` +
      `📱 *Username:* @${dbUser.username || 'N/A'}\n` +
      `🆔 *User ID:* \`${userId}\`\n` +
      `💰 *Amount:* Rs ${amount}\n` +
      `📝 *Ref ID:* \`${refId}\`\n` +
      `📱 *Method:* ${upiApp.toUpperCase()}\n` +
      `🕐 *Time:* ${utils.formatDateTime(new Date().toISOString())}`;

    await bot.sendPhoto(config.OWNER_ID, fileId, {
      caption: adminCaption,
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [
            { text: `✅ Approve Rs ${amount}`, callback_data: `adm_approve_${refId}` },
            { text: '❌ Reject', callback_data: `adm_reject_${refId}` }
          ],
          [{ text: '💬 Message User', callback_data: `adm_msg_${userId}` }]
        ]
      }
    });
  } catch (err) {
    console.error('Failed to notify admin:', err.message);
  }
}

// ─── Text Command Router (User shortcuts) ─────────────────────────────────────
async function handleTextCommand(userId, callbackData) {
  const banned = await utils.isUserBanned(userId);
  if (banned) return;

  const dbUser = await db.getUser(userId);
  if (!dbUser || !dbUser.terms_accepted) {
    await sendTermsMessage(userId);
    return;
  }

  if (callbackData === 'main_menu') {
    await showMainMenu(userId);
  } else if (callbackData === 'buy_product') {
    const m = await bot.sendMessage(userId, '⏳ Loading...');
    await showProducts(userId, m.message_id);
  } else if (callbackData === 'profile') {
    const m = await bot.sendMessage(userId, '⏳ Loading...');
    await showProfile(userId, m.message_id);
  } else if (callbackData === 'deposit') {
    const m = await bot.sendMessage(userId, '⏳ Loading...');
    await showDepositMenu(userId, m.message_id);
  } else if (callbackData === 'refer_earn') {
    const m = await bot.sendMessage(userId, '⏳ Loading...');
    await showReferral(userId, m.message_id);
  } else if (callbackData === 'support') {
    const m = await bot.sendMessage(userId, '⏳ Loading...');
    await showSupport(userId, m.message_id);
  }
}

// ─── Admin Text Input Router ───────────────────────────────────────────────────
// Returns true if input was handled (so main handler stops), false otherwise
async function handleAdminTextInput(userId, state, text) {
  // ─── Add Stock ───────────────────────────────────────────────────────────
  if (state.waitingAddStock) {
    const addCount = parseInt(text);
    if (isNaN(addCount) || addCount <= 0) {
      await bot.sendMessage(userId, '❌ Enter a valid positive number.');
      return true;
    }
    const database = await db.getDB();
    await database.run('UPDATE products SET stock = stock + ? WHERE id = ?', addCount, state.addingStockToProduct);
    clearState(userId);
    await bot.sendMessage(userId, `✅ Added *${addCount}* stock successfully! 🎉`, { parse_mode: 'Markdown', reply_markup: backBtn('« Back to Products', 'adm_products') });
    return true;
  }

  // ─── Product Edit ────────────────────────────────────────────────────────
  if (state.waitingProductEdit) {
    const { editingProductId, editingField } = state;
    const database = await db.getDB();
    let value = text;
    if (editingField === 'price_inr' || editingField === 'stock') {
      value = parseFloat(text);
      if (isNaN(value)) {
        await bot.sendMessage(userId, '❌ Enter a valid number.');
        return true;
      }
    }
    await database.run(`UPDATE products SET ${editingField} = ? WHERE id = ?`, value, editingProductId);
    clearState(userId);
    await bot.sendMessage(userId, `✅ Updated successfully! 🎉`, { parse_mode: 'Markdown', reply_markup: backBtn('« Back to Products', 'adm_products') });
    return true;
  }

  // ─── Add Product Flow ────────────────────────────────────────────────────
  if (state.addingProduct) {
    const ap = state.addingProduct;
    const steps = ['name', 'price_inr', 'stock', 'description', 'content'];
    const labels = ['Product Name', 'Price (Rs)', 'Stock Count', 'Description', 'Product Content'];
    const currentIdx = steps.indexOf(ap.step);

    ap.data[ap.step] = text;

    if (currentIdx < steps.length - 1) {
      ap.step = steps[currentIdx + 1];
      await bot.sendMessage(userId, `*Step ${currentIdx + 2}/${steps.length}:* Enter ${labels[currentIdx + 1]}: ✍️`, { parse_mode: 'Markdown' });
    } else {
      const database = await db.getDB();
      await database.run(
        `INSERT INTO products (name, price_inr, stock, description, content) VALUES (?, ?, ?, ?, ?)`,
        ap.data.name, parseFloat(ap.data.price_inr) || 0, parseInt(ap.data.stock) || 0, ap.data.description, ap.data.content
      );
      clearState(userId);
      await bot.sendMessage(userId,
        `✅ *Product added successfully!* 🎉\n\n📦 Name: ${ap.data.name}\n💰 Price: Rs ${ap.data.price_inr}\n📊 Stock: ${ap.data.stock}`,
        { parse_mode: 'Markdown', reply_markup: backBtn('« Back to Products', 'adm_products') }
      );
    }
    return true;
  }

  // ─── Rate / Referral / UPI / BNB / Links Settings ───────────────────────
  if (state.waitingRate) {
    const rate = parseFloat(text);
    if (isNaN(rate) || rate <= 0) {
      await bot.sendMessage(userId, '❌ Enter a valid rate (e.g. 90):');
      return true;
    }
    await db.setSetting('usdt_to_inr_rate', rate.toString());
    clearState(userId);
    await bot.sendMessage(userId, `✅ Rate updated: 1 USDT = Rs ${rate}`, { reply_markup: backBtn() });
    return true;
  }

  if (state.waitingRefReward) {
    const reward = parseFloat(text);
    if (isNaN(reward) || reward < 0) {
      await bot.sendMessage(userId, '❌ Enter a valid amount:');
      return true;
    }
    await db.setSetting('referral_reward_inr', reward.toString());
    clearState(userId);
    await bot.sendMessage(userId, `✅ Referral reward updated: Rs ${reward}`, { reply_markup: backBtn() });
    return true;
  }

  if (state.waitingUpiId) {
    await db.setSetting('upi_id', text);
    clearState(userId);
    await bot.sendMessage(userId, `✅ UPI ID updated: \`${text}\``, { parse_mode: 'Markdown', reply_markup: backBtn('« Back to Payments', 'adm_payments') });
    return true;
  }

  if (state.waitingUpiTextId) {
    await db.setSetting('upi_text_id', text);
    clearState(userId);
    await bot.sendMessage(userId, `✅ Display UPI Text ID updated: \`${text}\``, { parse_mode: 'Markdown', reply_markup: backBtn('« Back to Payments', 'adm_payments') });
    return true;
  }

  if (state.waitingBnbAddress) {
    await db.setSetting('bnb_address', text);
    clearState(userId);
    await bot.sendMessage(userId, `✅ BNB Address updated: \`${text}\``, { parse_mode: 'Markdown', reply_markup: backBtn('« Back to Payments', 'adm_payments') });
    return true;
  }

  if (state.waitingGroupLink) {
    await db.setSetting('group_link', text);
    clearState(userId);
    await bot.sendMessage(userId, `✅ Group link updated.`, { reply_markup: backBtn() });
    return true;
  }

  if (state.waitingChannelLink) {
    await db.setSetting('channel_link', text);
    clearState(userId);
    await bot.sendMessage(userId, `✅ Channel link updated.`, { reply_markup: backBtn() });
    return true;
  }

  if (state.waitingSupportLink) {
    await db.setSetting('support_link', text);
    clearState(userId);
    await bot.sendMessage(userId, `✅ Support link updated.`, { reply_markup: backBtn() });
    return true;
  }

  if (state.waitingNewPassword) {
    if (text.length < 4) {
      await bot.sendMessage(userId, '❌ Password too short. Minimum 4 characters:');
      return true;
    }
    config.ADMIN_PASSWORD = text;
    clearState(userId);
    await bot.sendMessage(userId,
      `✅ Password updated for this session!\n\n⚠️ Update your Render \`ADMIN_PASSWORD\` env variable too, otherwise it resets to the old one on next restart.`,
      { reply_markup: backBtn() }
    );
    return true;
  }

  // ─── Broadcast ───────────────────────────────────────────────────────────
  if (state.waitingBroadcast) {
    const users = await db.getAllUsers();
    clearState(userId);

    await bot.sendMessage(userId, `📢 Sending to ${users.length} users...`);

    let success = 0;
    let failed = 0;

    for (const u of users) {
      try {
        await bot.sendMessage(u.user_id, text, { parse_mode: 'Markdown' });
        success++;
        await new Promise(r => setTimeout(r, 50));
      } catch {
        failed++;
      }
    }

    await bot.sendMessage(userId, `📢 *Broadcast Complete!* ✅\n\n✅ Sent: ${success}\n❌ Failed: ${failed}`, { parse_mode: 'Markdown', reply_markup: backBtn() });
    return true;
  }

  // ─── Send Message to User ─────────────────────────────────────────────────
  if (state.waitingSendMsg) {
    const targetId = state.sendMsgTo;
    clearState(userId);
    try {
      await bot.sendMessage(targetId, `📨 *Message from Admin:*\n\n${text}`, { parse_mode: 'Markdown' });
    } catch (err) {
      console.error('notifyUser error:', err.message);
    }
    await bot.sendMessage(userId, `✅ Message sent to user \`${targetId}\``, { parse_mode: 'Markdown', reply_markup: backBtn('« Back to Users', 'adm_users') });
    return true;
  }

  return false; // not handled by admin flows
}

module.exports = { bot };
